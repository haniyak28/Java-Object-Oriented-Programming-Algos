/* Assignment 1 (100 marks in total; 5% of the final score of this course) 
 * 
 * Question 2 (20 marks)
 * 
 * Write a Java program to print the sum of two user input integer numbers.
 * Also submit a screenshot to demonstrate that you have successfully ran
 * javac and java commandline to compile and run the code of Q1_HelloWorld.java
 * 
 * INPUT: two user input integer numbers
 * OUTPUT: the sum of the two user input integer numbers
 * 
 * Hint1: you may use java.util.Scanner to take user input numbers.
 * 
 */

import java.util.Scanner;

public class Q2_SumTwoNumbers {
	public static void main(String[] args) {
		Scanner my_scanner = new Scanner(System.in); //initiating my_scanner object
		System.out.println("Enter any integer:"); //telling the user to input an integer
		int input1 = my_scanner.nextInt(); //reading input and saving it to the variable
		System.out.println("Enter another integer:"); //telling the user to input another integer
		int input2 = my_scanner.nextInt(); //reading input and saving it to the variable

		//outputting the sum of the integers the user inputted
		System.out.print("The sum of the integers is:");
		System.out.println(input1 + input2);
	}
}
