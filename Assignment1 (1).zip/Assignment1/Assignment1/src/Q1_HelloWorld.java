/* Assignment 1 (100 marks in total; 5% of the final score of this course) 
 * 
 * Question 1 (20 marks)
 * 
 * Write some code to implement the following class.
 * The goal is to print exactly the sentence: "Hello Java World!"
 * Also submit a screenshot to demonstrate that you have successfully ran
 * javac and java commandline to compile and run the code of Q1_HelloWorld.java
 * 
 * INPUT: n/a
 * OUTPUT: "Hello Java World!"
 */

public class Q1_HelloWorld {
    public static void main(String[] args){
        System.out.println("Hello Java World!"); //outputing the text "Hello Java World!"
    }
}
