/* Assignment 1 (100 marks in total; 5% of the final score of this course) 
 * 
 * Question 3 (20 marks)
 * 
 * Write a Java program to print the result of first user input real number divided by the second user input real number.
 * Also submit a screenshot to demonstrate that you have successfully ran
 * javac and java commandline to compile and run the code of Q1_HelloWorld.java
 *
 * INPUT: user input real number x, and user input real number y
 * OUTPUT: the result of x divided y. (The result should be printed with two significant digits after the decimal point.)
 * 
 * Hint1: you may use java.util.Scanner to take user input real numbers.
 * Hint2: you may use format string of System.out.printf() when printing the result.
 * 
 */

import java.util.Scanner;

public class Q3_DivideTwoNumbers {
	public static void main(String[] args) {
		Scanner my_scanner = new Scanner(System.in); //initiating my_scanner object
		System.out.println("Enter any real number:"); //telling the user to input a real number
		double real_numberx = my_scanner.nextDouble(); //reading input and saving it to the variable
		System.out.println("Enter any real number:"); //telling the user to input another real number
		double real_numbery = my_scanner.nextDouble(); //reading input and saving it to the variable
		double divided = real_numberx/real_numbery; //dividing the numbers and saving it to the divided variable
		System.out.printf("The divided value is:%.2f\n", divided); //outputting the divided value but formatted to only 2 decimal places
	}
}
