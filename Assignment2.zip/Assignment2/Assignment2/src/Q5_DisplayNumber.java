/* Assignment 2 (100 marks in total; 5% of the final score of this course)
 *
 * Question 5 (20 marks)
    Write a program in Java to display (i.e. print) the pattern like right angle triangle with a number.

 * INPUT: an integer number n
 * OUTPUT: print a right angle triangle corresponding to n

 * Example1: for n=3, the right angle triangle should be:
    1
    12
    123

 * Example2: for n=5, the right angle triangle should be:
    1
    12
    123
    1234
    12345

 */

import java.util.Scanner;

public class Q5_DisplayNumber {
    public static void main(String[] args) {
        Scanner my_scanner = new Scanner(System.in); //initiating my_scanner object
        System.out.println("Enter any integer number:"); //telling the user to input an integer
        int n_var = my_scanner.nextInt(); //reading input and saving it to the variable
        int previous_output = 1;
        int output_number;

        if ((0 < n_var) && (n_var<=9)){
            for (int i = 1; i < (n_var+1); i++) {
                if (i == 1)
                    System.out.println(i);
                else {
                    //take previous output and multiply it by 10 and add i to it
                    output_number = (previous_output * 10) + i;
                    System.out.println(output_number);
                    previous_output = output_number;
                }
            }
        }
        else
            System.out.println("error");
    }
}
