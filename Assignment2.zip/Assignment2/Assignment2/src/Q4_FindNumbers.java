/* Assignment 2 (100 marks in total; 5% of the final score of this course)
 *
 * Question 4 (20 marks)
    Write a Java program to print integer numbers between 1 to a user input integer n, which are divisible by 3, 5 and by both.

 * INPUT: a user input integer n
 * OUTPUT: all the integer numbers between 1 and n that are either divisible by 3 or by 5 or by both.

* Hint: For n=16, the output should be as follows.
    Divided by 3 -> 3, 6, 9, 12, 15.
    Divided by 5 -> 5, 10, 15.
    Divided by 3 and 5 -> 15.
 */

import java.util.*;
import java.util.Scanner;

public class Q4_FindNumbers {
    public static void main(String args[]) {
        Scanner my_scanner = new Scanner(System.in); //initiating my_scanner object
        System.out.println("Enter any integer number:"); //telling the user to input an integer
        int user_input = my_scanner.nextInt(); //reading input and saving it to the variable
        List<Integer> div_by_3=new ArrayList<Integer>();
        List<Integer> div_by_5=new ArrayList<Integer>();
        List<Integer> div_by_both=new ArrayList<Integer>();

        for (int i = 2; i <= user_input; i++) {
            if ((i % 3) == 0) {
                div_by_3.add(i);
            }
            if ((i % 5) == 0) {
                div_by_5.add(i);
            }
            if (((i % 5) == 0) && ((i % 3) == 0)) {
                div_by_both.add(i);
            }
        }
        System.out.println("Divided by 3 -> " + div_by_3.toString().replace("[","").replace("]","") + ".");
        System.out.println("Divided by 5 -> " + div_by_5.toString().replace("[","").replace("]","") + ".");
        System.out.println("Divided by 3 and 5 -> " + div_by_both.toString().replace("[","").replace("]","") + ".");
    }
}
