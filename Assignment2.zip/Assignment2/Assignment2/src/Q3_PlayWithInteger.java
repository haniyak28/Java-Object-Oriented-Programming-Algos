/* Assignment 2 (100 marks in total; 5% of the final score of this course)
 *
 * Question 3 (20 marks)
    Write a Java program that accepts an integer (n, 0 <= n <= 9) and computes the value of n+nn+nnn.

 * INPUT: a user input integer n
 * OUTPUT: the value of n+nn+nnn.

* Hint: For n=2, the output is 2+22+222=246
 */

import java.util.Scanner;

public class Q3_PlayWithInteger {
    public static void main(String[] args) {
        Scanner my_scanner = new Scanner(System.in); //initiating my_scanner object
        System.out.println("Enter any integer number:"); //telling the user to input an integer
        int value1 = my_scanner.nextInt(); //reading input and saving it to the variable
        if ((value1 <= 9) && (value1 >= 0)) {
            int value2 = (value1 * 10) + value1;
            int value3 = (value1 * 100) + value2;
            System.out.println(value1 + value2 + value3);
        }
        else {
            System.out.println("error");
        }
    }
}
