/* Assignment 2 (100 marks in total; 5% of the final score of this course)
 *
 * Question 2 (20 marks)
    Write a Java program to convert a decimal number to octal number.

    Decimal number: The decimal numeral system is the standard system for denoting integer and non-integer numbers. It is also called base-ten positional numeral system.
    Octal number: The octal numeral system is the base-8 number system, and uses the digits 0 to 7.


 * INPUT: a user input decimal number x
 * OUTPUT: an octal number y converted from x

* Hint: For a decimal number x=1256, the corresponding octal number is y=2350.
 */

import java.util.*;
import java.util.Scanner;

public class Q2_Decimal2Octal {
    public static void main(String args[])
    {
        Scanner my_scanner = new Scanner(System.in); //initiating my_scanner object
        System.out.println("Enter any decimal number:"); //telling the user to input an integer
        int decimal = my_scanner.nextInt(); //reading input and saving it to the variable
        int octal = 0;
        int remainder;
        int quotient = decimal;
        int multiplier = 1;
        List<Integer> octal_list=new ArrayList<Integer>();

        while (quotient >= 8) {
            remainder = quotient % 8;
            quotient = quotient / 8;
            octal_list.add(remainder);
        }
        octal_list.add(quotient);

        for (int i = 0; i < (octal_list.size()); i++) {
            octal = octal + (octal_list.get(i) * multiplier);
            multiplier = multiplier*10;
        }
        System.out.println(octal);
    }
    //pseudo code
        //Check if the decimal number is less than 8.
        //      If yes, the octal number is the same.
        //      If no, then proceed forward.
        // Repeat this process (dividing the quotient again by 8) until we get the quotient to be less than 8.
        //      Divide by 8 (octal base number).
        //      Note down the quotient and the remainder in the quotient-remainder form.
        //      save remainders into a list, but keep adding the next remainder to the beginning of the list and not end
        //save the last quotient (less than 8 to the beginning of the list too
        //use join command to make the list into a string of all those numbers, giving us the octal number.

        // The octal number is considered by reading all the remainders and the last quotient from bottom to top.
}

